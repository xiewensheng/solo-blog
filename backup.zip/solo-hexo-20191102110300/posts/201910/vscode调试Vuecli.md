title: vscode 调试Vue-cli
date: '2019-10-25 14:43:06'
updated: '2019-10-25 14:43:06'
tags: [待分类]
permalink: /articles/2019/10/25/1571985786922.html
---
## Visual Stuido Code 安装插件

点击 Visual Studio Code 左侧边栏的**扩展**按钮， 然后在搜索框输入**Debugger for Chrome**并安装插件，再输入，安装完成后点击 reload 重启 VS Code

## 添加 Visual Studio Code 配置

* 点击 Visual Studio Code 左侧边栏的 **调试** 按钮， 在弹出的调试配置窗口中点击 *设置* 小齿轮， 然后选择 chrome, VS Code 将会在工作区根目录生成.vscode 目录，里面会有一个 lanch.json 文件并会自动打开
* 用下面的配置文件覆盖自动生成的 lanch.json 文件内容。
    
    ```
    {
      // Use IntelliSense to learn about possible attributes.
      // Hover to view descriptions of existing attributes.
      // For more information, visit: https://go.microsoft.com/fwlink/?linkid=830387
      "version": "0.2.0",
      "configurations": [
        {
          "type": "chrome",
          "request": "attach",
          "name": "Attach to Chrome",
          "port": 9222,
          "webRoot": "${workspaceRoot}/src",
          "url": "http://localhost:8080/#/",
          "sourceMaps": true,
          "sourceMapPathOverrides": {
            "webpack:///src/*": "${webRoot}/*"
          }
        }
      ]
    }
    ```
    
字段说明：

| 字段 |  含义|
| :-: |  :-: |
|version |  定义这个配置文件的版本，生成的时候默认是0.2.0|
| configurations	 | 配置域|
| name |  配置文件的名字，可以自定义 |
| request| 配置文件的请求类型，有launch和attach两种，launch是需要服务器的需要配置url |
| url	|  指定访问的链接 |
| webRoot	|  指定根目录或者执行文件 |
| sourceMaps	| 默认是启用的，对于打包的调试 |
| userDataDir	|  临时目录,专门保存调试过程产生的东西，这个字段是为了重新打开一个浏览器窗口，不会强制关闭已经打开的浏览器 |

| 预定变量 |  含义|
| :-: |  :-: |
|${workspaceRoot}|  VSCode中打开文件夹的路径 |
| ${workspaceRootFolderName}| VSCode中打开文件夹的路径, 但不包含"/" |
| ${file}|  当前打开的文件  |
| ${relativeFile} | 当前打开的文件,相对于workspaceRoot |
| ${fileBasename} | 当前打开文件的文件名, 不含扩展名 |
| ${fileDirname} |  当前打开文件的目录名 |
| ${fileExtname} | 当前打开文件的扩展名 |
| ${cwd}|  当前启动时的工作目录 |

## 修改 webpack 的 sourcemap

如果你是基于 webpack 打包的 vue 项目， 可能会存在断点不匹配的问题, 还需要做些修改：

* 打开根目录下的 config 目录下的 index.js 文件
* 将**dev** 节点下的 **devtool** 值改为 *'eval-source-map'*
* 将**dev**节点下的 **cacheBusting** 值改为 *false*

## 开始调试吧

一切具备了， 现在验收成果了

* 通过第一步的方式以远程调试打开的方式打开 Chrome
* 在 vue 项目中执行`npm run dev`以调试方式启动项目
* 点击 VS Code 左侧边栏的调试按钮，选择 *Attach to Chrome* 并点击绿色开始按钮，正常情况下就会出现调试控制条。
* 现在就可以在.vue文件的js代码中打断点进行调试了。


参考文章；
[https://segmentfault.com/a/1190000013392459](https://segmentfault.com/a/1190000013392459)
[https://blog.csdn.net/lihefei_coder/article/details/91955498](https://blog.csdn.net/lihefei_coder/article/details/91955498)
