title: 我在 GitHub 上的开源项目
date: '2019-10-06 10:52:58'
updated: '2019-10-06 10:52:58'
tags: [开源, GitHub]
permalink: /my-github-repos
---
<!-- 该页面会被定时任务自动覆盖，所以请勿手工更新 -->
<!-- 如果你有更漂亮的排版方式，请发 issue 告诉我们 -->

### 1. [solo-blog](https://github.com/xiewensheng/solo-blog) <kbd title="主要编程语言"></kbd> <span style="font-size: 12px;">[🤩`1`](https://github.com/xiewensheng/solo-blog/watchers "关注数")&nbsp;&nbsp;[⭐️`0`](https://github.com/xiewensheng/solo-blog/stargazers "收藏数")&nbsp;&nbsp;[🖖`0`](https://github.com/xiewensheng/solo-blog/network/members "分叉数")&nbsp;&nbsp;[🏠`http://www.stvarnik.top`](http://www.stvarnik.top "项目主页")</span>

精灵鼠的冬天 - 佛曰：缘来则去,缘聚则散,缘起则生,缘落则灭



---

### 2. [configBackup](https://github.com/xiewensheng/configBackup) <kbd title="主要编程语言">Python</kbd> <span style="font-size: 12px;">[🤩`1`](https://github.com/xiewensheng/configBackup/watchers "关注数")&nbsp;&nbsp;[⭐️`0`](https://github.com/xiewensheng/configBackup/stargazers "收藏数")&nbsp;&nbsp;[🖖`0`](https://github.com/xiewensheng/configBackup/network/members "分叉数")</span>

这里是sublime的配置文件



---

### 3. [myProject](https://github.com/xiewensheng/myProject) <kbd title="主要编程语言">JavaScript</kbd> <span style="font-size: 12px;">[🤩`1`](https://github.com/xiewensheng/myProject/watchers "关注数")&nbsp;&nbsp;[⭐️`0`](https://github.com/xiewensheng/myProject/stargazers "收藏数")&nbsp;&nbsp;[🖖`0`](https://github.com/xiewensheng/myProject/network/members "分叉数")</span>

毕业



---

### 4. [demo](https://github.com/xiewensheng/demo) <kbd title="主要编程语言">HTML</kbd> <span style="font-size: 12px;">[🤩`1`](https://github.com/xiewensheng/demo/watchers "关注数")&nbsp;&nbsp;[⭐️`0`](https://github.com/xiewensheng/demo/stargazers "收藏数")&nbsp;&nbsp;[🖖`0`](https://github.com/xiewensheng/demo/network/members "分叉数")</span>

一些js小demo



---

### 5. [code](https://github.com/xiewensheng/code) <kbd title="主要编程语言">PHP</kbd> <span style="font-size: 12px;">[🤩`1`](https://github.com/xiewensheng/code/watchers "关注数")&nbsp;&nbsp;[⭐️`0`](https://github.com/xiewensheng/code/stargazers "收藏数")&nbsp;&nbsp;[🖖`0`](https://github.com/xiewensheng/code/network/members "分叉数")</span>



