title: Markdown学习
date: '2019-07-19 16:15:02'
updated: '2019-07-24 16:49:54'
tags: [Markdown]
permalink: /articles/2019/07/19/1563524101996.html
---
#### 1. 标题
## 井号表示标题
#### 2. 斜体和粗体(语法格式：\**..**和\*..\*)
**语法示例**：\*\*粗体\*\*和\*斜体\*
**俩个星号表示这是粗体**
*一个星号表示斜体*
#### 3. 下划线(语法格式：\<u>..\</u>)
**语法示例**：\<u>文字\</u>
<u>下户线使用u标签</u>
#### 4. 删除线(语法格式：\~~..~~)
**语法示例**：\~~文字~~
~~删除线使用俩个波浪线~~
#### 5. 分割线(语法格式：\***)
**语法示例**：\***
三个单独的一行星号表示分割线 
\***
***
#### 6. 引用(语法格式：\>)
**语法示例**：\*
>用大于号表示你引用示例，结尾遗留一行空表示引用结束

#### 7. 列表(语法格式：\* )
**语法示例**：\*
* 使用单独一个星号表示符号列表
* 列表文字和星号之间需要空格呢
* 结尾下一行遗留为空表示结束了

1. 数字列表使用数字加点号就可以了
2. 并且文字与点号之间需要空格
#### 8. 待办事项(语法格式：\* [ ])
**语法示例**：\[x]
* [ ] 这是添加任务呢
* [x] 中间输入x表示任务完成了
* [x] x的前后不能有空格呢

#### 9. 插入链接（语法格式：\[]()）
**语法示例**：\[中括号是文字](小括号里面是地址)
[中括号是文字](小括号里面是地址)

#### 10. 插入图片（语法格式：\!\[image]()）
**语法示例**：
\!\[image](https://www.yinxiang.com/blog/wp-content/uploads/2018/07/%E5%94%AE%E7%A5%A8%E5%BE%AE%E4%BF%A1%E5%B0%81%E9%9D%A22.png)@h=100w=200

![image](https://www.yinxiang.com/blog/wp-content/uploads/2018/07/%E5%94%AE%E7%A5%A8%E5%BE%AE%E4%BF%A1%E5%B0%81%E9%9D%A22.png)@h=100w=200

另外，针对插入的本地图片可以控制图片大小，在拖拽、拷贝或者点击插入本地图片之后，直接在图片名称后面（无需空格）添加以下语法均可以按照以下要求控制图片大小：
* @w=300
* @h=150
* @w=200h=100
* @h=100w=200

#### 11. 插入表格
**语法示例**：
\| 帐户类型 | 免费帐户 | 标准帐户 | 高级帐户 |
\| :--- | :---: | --- | ---: |
\| 帐户流量 | 60M | 1GB | 10GB |
\| 设备数目 | 2台 | 无限制 | 无限制 |
\| 当前价格 | 免费 | ￥8.17/月 | ￥12.33/月|

| 帐户类型 | 免费帐户 | 标准帐户 | 高级帐户 |
| :--- | :---: | --- | ---: |
| 帐户流量 | 60M | 1GB | 10GB |
| 设备数目 | 2台 | 无限制 | 无限制 |
| 当前价格 | 免费 | ￥8.17/月 | ￥12.33/月|

注：  :—代表左对齐，—:代表右对齐，:—:代表居中对齐，-数目至少一个，:没有默认左对齐，第二行必须有，否则不是表格形式。以上格式代表是三行三列的表格。
#### 12. 图表

目前支持饼状图、折线图、柱状图和条形图，只需将 type 改为对应的pie、line、column 和 bar。
**语法示例**：
\`\`\`chart
,预算,收入,花费,债务
June,5000,8000,4000,6000
July,3000,1000,4000,3000
Aug,5000,7000,6000,3000
Sep,7000,2000,3000,1000
Oct,6000,5000,4000,2000
Nov,4000,3000,5000,


type: pie
title: 每月收益
x.title: Amount
y.title: Month
y.suffix: $
\`\`\`
```chart
,预算,收入,花费,债务
June,5000,8000,4000,6000
July,3000,1000,4000,3000
Aug,5000,7000,6000,3000
Sep,7000,2000,3000,1000
Oct,6000,5000,4000,2000
Nov,4000,3000,5000,


type: pie
title: 每月收益
x.title: Amount
y.title: Month
y.suffix: $
```
#### 13. 插入行内代码或代码块
**语法示例**：
\`\`\`java
package app.controller;



import javax.servlet.http.HttpSession;

public class MyController extends Controller {

}
\`\`\`

```java
package app.controller;



import javax.servlet.http.HttpSession;

public class MyController extends Controller {

}
```
#### 14. 插入数学公式

Markdown 支持绝大多数的 LaTeX 数学公式：
**语法示例**：
\`\`\`math
e^{i\pi} + 1 = 0
\`\`\`
```math
e^{i\pi} + 1 = 0
```
更多数学公式的输入可以参考：[https://khan.github.io/KaTeX/docs/supported.html](https://khan.github.io/KaTeX/docs/supported.html)

#### 15. 插入流程图

**语法示例**：
\`\`\`mermaid
graph TD
A[模块A] -->|A1| B(模块B)
B --> C{判断条件C}
C -->|条件C1| D[模块D]
C -->|条件C2| E[模块E]
C -->|条件C3| F[模块F]
\`\`\`

```mermaid
graph TD
A[模块A] -->|A1| B(模块B)
B --> C{判断条件C}
C -->|条件C1| D[模块D]
C -->|条件C2| E[模块E]
C -->|条件C3| F[模块F]
```
#### 16. 插入时序图

**语法示例**：
\`\`\`mermaid
sequenceDiagram
A->>B: 是否已收到消息？
B-->>A: 已收到消息
\`\`\`

```mermaid
sequenceDiagram
A->>B: 是否已收到消息？
B-->>A: 已收到消息
```
#### 17. 插入甘特图

**语法示例**：
\`\`\`mermaid
gantt
title 甘特图
dateFormat YYYY-MM-DD
section 项目A
任务1 :a1, 2018-06-06, 30d
任务2 :after a1 , 20d
section 项目B
任务3 :2018-06-12 , 12d
任务4 : 24d
\`\`\`

```mermaid
gantt
title 甘特图
dateFormat YYYY-MM-DD
section 项目A
任务1 :a1, 2018-06-06, 30d
任务2 :after a1 , 20d
section 项目B
任务3 :2018-06-12 , 12d
任务4 : 24d
```

#### 18. 设置目录

设置之后可以自动根据设置的分级标题来自动生成目录。
**语法示例** ：[TOC]
[TOC]

本文转载链接：[https://list.yinxiang.com/markdown/eef42447-db3f-48ee-827b-1bb34c03eb83.php ](https://list.yinxiang.com/markdown/eef42447-db3f-48ee-827b-1bb34c03eb83.php )