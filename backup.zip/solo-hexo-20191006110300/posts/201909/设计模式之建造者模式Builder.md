title: 设计模式之建造者模式(Builder)
date: '2019-09-25 11:12:21'
updated: '2019-09-25 11:15:20'
tags: [设计模式]
permalink: /articles/2019/09/25/1569381141394.html
---
![](https://img.hacpai.com/bing/20180801.jpg?imageView2/1/w/960/h/540/interlace/1/q/100)

## 一、前言

今天我们讨论一下 Builder 建造者模式，这个 Builder，其实和模板模式非常的像，但是也有区别，那就是在模板模式中父类对子类中的实现进行操作，在父类之中进行一件事情的处理，但是在 Builder 模式之中，父类和子类都不用关心怎么处理，而是用另一个类来完成对这些方法的有机组合，这个类的职责就是监工，规定了到底要怎么样有机的组合这些方法。在监工类（Director）中，将父类组合进去，然后调用父类的操作来抽象的实现一件事情，这就是面向接口（抽象）变成的妙处了，当然这个 Builder 可以使接口也可以是抽象类，在这里我们使用抽象类。

# 建造者模式

建造者模式（Builder Pattern）使用多个简单的对象一步一步构建成一个复杂的对象。这种类型的设计模式属于创建型模式，它提供了一种创建对象的最佳方式。

一个 Builder 类会一步一步构造最终的对象。该 Builder 类是独立于其他对象的。

## 介绍

**意图：** 将一个复杂的构建与其表示相分离，使得同样的构建过程可以创建不同的表示。

**主要解决：** 主要解决在软件系统中，有时候面临着"一个复杂对象"的创建工作，其通常由各个部分的子对象用一定的算法构成；由于需求的变化，这个复杂对象的各个部分经常面临着剧烈的变化，但是将它们组合在一起的算法却相对稳定。

**何时使用：** 一些基本部件不会变，而其组合经常变化的时候。

**如何解决：** 将变与不变分离开。

**关键代码：** 建造者：创建和提供实例，导演：管理建造出来的实例的依赖关系。

**应用实例：**  1、去肯德基，汉堡、可乐、薯条、炸鸡翅等是不变的，而其组合是经常变化的，生成出所谓的"套餐"。 2、JAVA 中的 StringBuilder。

**优点：**  1、建造者独立，易扩展。 2、便于控制细节风险。

**缺点：**  1、产品必须有共同点，范围有限制。 2、如内部变化复杂，会有很多的建造类。

**使用场景：**  1、需要生成的对象具有复杂的内部结构。 2、需要生成的对象内部属性本身相互依赖。

**注意事项：** 与工厂模式的区别是：建造者模式更加关注与零件装配的顺序。

**UML图：** 

![null](https://www.runoob.com/wp-content/uploads/2019/08/1157683-20180626180216963-8235726.png)


## 二、Builder 模式代码
#### Builder 抽象类：
Builder.java
```java
public abstract class Builder {
    
    public abstract void makeString(String str);
    public abstract void makeTitle(String title);
    public abstract void makeItems(String[] items);
    public abstract void close();
    
}
```
#### HtmlBuilder 实现类：

HtmlBuilder.java
```java
import java.io.FileWriter;
import java.io.IOException;
import java.io.PrintWriter;
 
public class HtmlBuilder extends Builder {
 
    private String filename;
    private PrintWriter pw;
    public void makeTitle(String title) {
        filename="D:\\"+title+".html";
        try {
            pw=new PrintWriter(new FileWriter(filename));
        } catch (IOException e) {
            e.printStackTrace();
        }
        pw.println("<html><head><title>"+title+"</title></head><body>");
        pw.println("<h1>"+title+"</h1>");
    }
    
    public void makeString(String str) {
        pw.println("<p>"+str+"</p>");
    }
 
    public void makeItems(String[] items) {
        pw.println("<ul>");
        for(int i=0;i<items.length;i++){
            pw.println("<li>"+items[i]+"</li>");
        }
        pw.println("</ul>");
    }
 
    public void close() {
        pw.println("</body></html>");
        pw.close();
    }
    public String getResult(){
        return filename;
    }
}
```

#### TextBuilder 实现类：

TextBuilder.java
```java
public class TextBuilder extends Builder {
 
    StringBuffer sb=new StringBuffer();
    
    public void makeTitle(String title) {
        sb.append("=====================");
        sb.append("["+title+"]"+"\n");
    }
    
    public void makeString(String str) {
        sb.append("@"+str+"\n");
    }
 
    public void makeItems(String[] items) {
        for(int i=0;i<items.length;i++){
            sb.append("   ."+items[i]+"\n");
        }
    }
 
    public void close() {
        sb.append("=====================");
    }
    
    public String getResult(){
        return sb.toString();
    }
    
}
```

#### Director 监工类：

Director.java
```java
public class Director {
    private Builder builder;
    public Director(Builder builder){
        this.builder=builder;
    }
    public void construct(){
        String [] items1=new String[]{"奏国歌","升国旗"};
        String [] items2=new String[]{"观众鼓掌","有序撤离"};
        builder.makeTitle("今日头条");
        builder.makeString("毕业典礼");
        builder.makeItems(items1);
        builder.makeString("典礼结束");
        builder.makeItems(items2);
        builder.close();
    }
}
```
#### Main 类：

Director.java
```java
public class Main {
 
    public static void main(String[] args) {
        //String choice="plain";
        String choice="html";
        if(choice=="plain"){
            TextBuilder t=new TextBuilder();
            Director d=new Director(t);
            d.construct();
            System.out.println(t.getResult());
        }else if(choice=="html"){
            HtmlBuilder html=new HtmlBuilder();
            Director d=new Director(html);
            d.construct();
            System.out.println(html.getResult());
        }else{
            usage();
        }
 
    }
 
    private static void usage() {
        System.out.println("使用 plain，编辑文本文件");
        System.out.println("使用 html，编辑网页文件");
    }
 
}
```
#### 运行结果

![null](https://www.runoob.com/wp-content/uploads/2019/08/1157683-20180626181209288-2015291769.png)

或者：

![null](https://www.runoob.com/wp-content/uploads/2019/08/1157683-20180626181209288-2015291769.png)


## 三、总结
关于Builder模式，我们一定要分清和模板方法的区别，其实就是到底谁承担了"监工"的责任，在模板方法中父类承担了这个责任，而在Builder中，有另外一个专门的类来完成这样的操作，这样做的好处是类的隔离，比如说在Main中，用户根本就不知道有Builder这个抽象类，同样的Director这个监工的根本就不管到底是哪一个实现类，因为任何一个都会被转换为父类，然后进行处理（面向抽象编程的思想），因此很好的实现了隔离，同样的这样设计的好处是复用了，隔离的越好复用起来就越方便，我们完全可以思考，假如还有另外一个监工，使用了不同的construct方法来组装这些复杂的事件，那么对于原来的代码我们不用做任何的修改，只用增加这样的一个监工类，然后定义好相应的方法就好了，之后再Main中使用，这样的一种思想使得我们不用修改源代码，复用（Builder以及其子类）就很方便了，同样的，如果想增加一个新的Builder的子类，只要照着父类的方法进行填充，再加上自己的方法就好了，完全不用修改代码，这也是一种复用，因此这种复用（组件）的思想在设计模式中随处可见，本质就是高内聚低耦合，组件开发，尽量不修改原来的代码，有可扩展性，理解了这一点，我们再看看模板方法，责任全放在了父类里，如果责任需要改变，则必须要修改父类中的责任方法了，这样就修改了原来的代码，不利于复用，这也是两者的本质区别。

---

原文地址：https://www.cnblogs.com/zyrblog/p/9230630.html
