title: elementUI+springboot文件上传与下载
date: '2019-11-15 17:01:23'
updated: '2019-11-19 16:45:19'
tags: [vue]
permalink: /articles/2019/11/15/1573808483588.html
---
前言：今天捣鼓这个上传下载捣鼓了一天  各种坑啊  所以记录一下过程以备后需。先说说遇到的坑吧：
1. 由于项目使用了验证token机制，所有接口访问都要验证token，而我一开始没注意到这个，用elementUI的submit()是不会带上token的，这个时候就相当于直接访问接口，然后接口必然返回401，这个只要在elementUI的el-upload加上header属性带上token就ok了，
2. 在下载的时候，用jquery发送请求，响应成功但是没有进入success。这个是由于我接口返回的流类型，而ajax接受的类型(xml、html、script、JSON、jsonp、text)没有类型。所以不会进入success方法中。然后我使用了axios发送请求就可以了，具体怎么解决请看下文。

### 1.文件上传

#### 前端代码
```
<!-- 文件上传 -->
      <el-upload class="upload-demo" :headers="headers" ref="upload" :auto-upload="false" :limit="1"
                 action="../floodDuty/upload" :on-change="handleChange" :file-list="fileList">
        <!-- <el-button size="small" type="primary">点击上传</el-button>-->
        <el-button type="primary" slot="trigger" size="small" style="width: 150px">2选择文件</el-button>
        <el-button style="margin-left: 50px;" size="small" type="success" @click="submitUpload">3导入资料</el-button>
      </el-upload>
```
#### js代码
```
submitUpload (){
            var vm = this;
            vm.$refs.upload.submit();
            // Util.showSuccess(vm,"上传成功");
          },
          handleChange (file,fileList){
            this.fileList = fileList.slice(-3);
          },
```
#### 后端java代码
```
//处理文件上传
    @RequestMapping(value="/upload", method = RequestMethod.POST)
    public RetCode<?> uploadFloodFile(@RequestParam("file") MultipartFile file, HttpServletRequest request) throws IOException {
	System.out.println(file.getName);
        return null;
    }
```

### 文件下载
[用的阿里的EasyExcel下载excel作为例子]([https://alibaba-easyexcel.github.io](https://alibaba-easyexcel.github.io/))
#### 前端代码
```
<el-button @click="downLoad" :loading="btnLoading" type="success" icon="el-icon-search">查询22</el-button>
```
#### js代码
```
downLoad(){
this.$axios.post("../floodDuty/download",{},{
                      responseType:'blob'    // 设置响应数据类型
                    }).then(res=>{
                    debugger;
                  const content = res;
                  const blob = new Blob([content]);
                  const fileName = '导出信息.xls';
                  if ('download' in document.createElement('a')) { // 非IE下载
                    const elink = document.createElement('a');
                    elink.download = fileName;
                    elink.style.display = 'none';
                    elink.href = URL.createObjectURL(blob);
                    document.body.appendChild(elink);
                    elink.click()
                    URL.revokeObjectURL(elink.href);// 释放URL 对象
                    document.body.removeChild(elink)
                  } else { // IE10+下载
                    navigator.msSaveBlob(blob, fileName)
                  }
                })
              },
```
#### 后端java代码
```
@PostMapping("/download")
    public void download(HttpServletResponse response) throws IOException {
        try {
            response.setContentType("application/vnd.ms-excel");
            response.setCharacterEncoding("utf-8");
            // 这里URLEncoder.encode可以防止中文乱码 当然和easyexcel没有关系
            String fileName = URLEncoder.encode("测试", "utf-8");
            response.setHeader("Content-disposition", "attachment;filename=" + fileName + ".xlsx");
            //EasyExcelUtil.testWirter(response.getOutputStream());
            EasyExcel.write(response.getOutputStream()).autoCloseStream(Boolean.FALSE).sheet("模板").doWrite(dataList());
        } catch (Exception e) {
            // 重置response
            response.reset();
            response.setContentType("application/json");
            response.setCharacterEncoding("utf-8");
            Map<String, String> map = new HashMap<>();
            map.put("status", "failure");
            map.put("message", "下载文件失败" + e.getMessage());
            response.getWriter().println(JSON.toJSONString(map));
        }
    }
```~~~~


