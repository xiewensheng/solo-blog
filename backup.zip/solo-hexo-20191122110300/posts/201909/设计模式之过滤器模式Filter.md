title: 设计模式之过滤器模式(Filter)
date: '2019-09-26 16:25:52'
updated: '2019-09-26 16:25:52'
tags: [设计模式]
permalink: /articles/2019/09/26/1569486352398.html
---
# 1Filter Pattern 过滤器模式
 **目的**：使用不同的标准来过滤一组对象，通过逻辑运算以解耦的方式把它们连接起来；
**实现**：制定不同的规则来对一组对象进行过滤，然后对过滤结果进行分组。

> 1.结合多个标准来获得单一标准。

# 2 实现
代码场景：中国移动有很多营销活动，而这些营销活动的对象是有要求的，有的需要判断在网时长，有的需要有最低套餐要求等；
1.中国移动客户是目标角色；
2.它不同营销活动的要求是过滤器角色；

## 2.1 代码实现
抽象过滤器角色：Filter
```
public interface Filter {
	public List<Consumer> filtrate(List<Consumer> consumers);
}
```
具体过滤器角色：赠送移动宽带过滤器
```
public class BroadbandFilter implements Filter {
	@Override
	public List<Consumer> filtrate(List<Consumer> consumers) {
		List<Consumer> cs = new ArrayList<Consumer>();
		// 手机套餐为138以上 赠送移动宽带100M一年
		for (Consumer c : consumers) {
			if (c.getCombos() >= 138) {
				cs.add(c);
			}
		}
		return cs;
	}
}
```
具体过滤器角色：赠送流量过滤器
```
public class FreeFlowFilter implements Filter {

	@Override
	public List<Consumer> filtrate(List<Consumer> consumers) {
		List<Consumer> cs = new ArrayList<Consumer>();
		// 在网年份大于5年 赠送10G移动流量
		for (Consumer c : consumers) {
			if (c.getExistsYears() >= 5) {
				cs.add(c);
			}
		}
		return cs;
	}
}
```
具体过滤器角色：生日提醒过滤器
```
public class BirthdayRemindFilter implements Filter {

	@Override
	public List<Consumer> filtrate(List<Consumer> consumers) {
		List<Consumer> cs = new ArrayList<Consumer>();
		// 星级为5星级以上 赠送生日提醒
		for (Consumer c : consumers) {
			if (c.getCombos() >= 138) {
				cs.add(c);
			}
		}
		return cs;
	}
}
```
## 2.2 涉及角色
过滤器模式包含如下两个角色：

1. AbstractFilter（抽象过滤器角色）：在客户端可以调用它的方法，在抽象过滤器角色中可以知道相关的（一个或者多个）子系统的功能和责任；在正常情况下，它将所有从客户端发来的请求委派到相应的实现类去，传递给相应的实现类对象处理。
2. ConcreteFilter（具体滤器角色）：在客户端可以调用它的方法，在具体滤器角色会对目标对象集合进行逻辑过滤，最后再返回一个过滤后的集合。
3. Subject（被过滤角色）：在软件系统中可以有一个或者多个目标角色，在具体过滤器中会对目标角色进行逻辑处理以查看是否是我想要的。

## 2.3 调用
调用者：
```
public class Client {

	public static void main(String[] args) {
		Consumer zhangft = new Consumer("张奉天", 1, 5, 138);
		Consumer ruiBo = new Consumer("芮博", 5, 2, 238);
		Consumer zhongJj = new Consumer("仲军军", 10, 4, 1);

		List<Consumer> cs = new ArrayList<Consumer>();
		cs.add(zhangft);
		cs.add(ruiBo);
		cs.add(zhongJj);

		Filter broadbandFilter = new BroadbandFilter();
		Filter freeFlowFilter = new FreeFlowFilter();
		Filter birthdayRemindFilter = new BirthdayRemindFilter();

		System.out.println("移动宽带免费一年用户:");
		List<Consumer> broadband = broadbandFilter.filtrate(cs);
		printList(broadband, "移动宽带");
		System.out.println("免费赠送移动流量用户:");
		List<Consumer> freeFlow = freeFlowFilter.filtrate(cs);
		printList(freeFlow, "流量10G");
		System.out.println("赠送生日提醒用户:");
		List<Consumer> birthdayRemind = birthdayRemindFilter.filtrate(cs);
		printList(birthdayRemind, "生日提醒功能");

	}
	private static void printList(List<Consumer> cs, String bussiness) {
		for (Consumer c : cs) {
			System.out.println("[" + c.getStar() + "]星级用户[" + c.getName()
					+ "],在网[" + c.getExistsYears() + "],当前套餐为[" + c.getCombos()
					+ "],免费赠送[" + bussiness + "]");
		}
	}

}
```
结果:

> 移动宽带免费一年用户:
[5]星级用户[张奉天],在网[1],当前套餐为[138],免费赠送[移动宽带]
[2]星级用户[芮博],在网[5],当前套餐为[238],免费赠送[移动宽带]
免费赠送移动流量用户:
[2]星级用户[芮博],在网[5],当前套餐为[238],免费赠送[流量10G]
[4]星级用户[仲军军],在网[10],当前套餐为[1],免费赠送[流量10G]
赠送生日提醒用户:
[5]星级用户[张奉天],在网[1],当前套餐为[138],免费赠送[生日提醒功能]
[2]星级用户[芮博],在网[5],当前套餐为[238],免费赠送[生日提醒功能]

[原文链接：https://blog.csdn.net/weixx3/article/details/80233991](https://blog.csdn.net/weixx3/article/details/80233991)
