title: 设计模式之装饰器模式(Decorator)
date: '2019-09-26 16:48:27'
updated: '2019-09-26 16:48:27'
tags: [设计模式]
permalink: /articles/2019/09/26/1569487707788.html
---
# Decorator Pattern 装饰器模式
**目的**：在不改变一个对象本身功能的基础上给对象增加新的行为，即增强功能；
**实现**：在抽象修饰类中通过聚合方式将被修饰类引入，增强功能的细节交给子类实现。

> * 为了增加功能又不想增加很多子类的情况下使用；
> * 动态地给一个对象增加一些额外职责，就增加对象功能来说，装饰模式比生成子类实现更为灵活；
> * 跟代理模式相比，装饰器模式强调增加新的功能；
## 实现

我们将创建一个 *Shape* 接口和实现了 *Shape* 接口的实体类。然后我们创建一个实现了 *Shape* 接口的抽象装饰类 *ShapeDecorator*，并把 *Shape* 对象作为它的实例变量。

*RedShapeDecorator* 是实现了 *ShapeDecorator* 的实体类。

*DecoratorPatternDemo*，我们的演示类使用 *RedShapeDecorator* 来装饰 *Shape* 对象。
![image.png](https://img.hacpai.com/file/2019/09/image-1e2a91ca.png)
### 步骤 1
创建一个接口：

#### Shape.java

```
public  interface  Shape {  
  void  draw(); 
}
```

### 步骤 2

创建实现接口的实体类。

#### Rectangle.java
```
public class Rectangle implements Shape {  
  
 @Override  
 public void draw() {  
 System.out.println("Shape: Rectangle");  
 }  
}  
```
#### Circle.java

```
public class Circle implements Shape {

  @Override
  public void draw() {
    System.out.println("Shape: Circle");
  }
}
```

### 步骤 3

创建实现了 *Shape* 接口的抽象装饰类。

#### ShapeDecorator.java

```
public abstract class ShapeDecorator implements Shape {
  protected Shape decoratedShape;

  public ShapeDecorator(Shape decoratedShape){
    this.decoratedShape = decoratedShape;
  }

  public void draw(){
    decoratedShape.draw();
  }
}
```

### 步骤 4

创建扩展了 *ShapeDecorator* 类的实体装饰类。

#### RedShapeDecorator.java

```
public class RedShapeDecorator extends ShapeDecorator {

  public RedShapeDecorator(Shape decoratedShape) {
    super(decoratedShape);
  }

  @Override
  public void draw() {
    decoratedShape.draw();
    setRedBorder(decoratedShape);
  }

  private void setRedBorder(Shape decoratedShape){
    System.out.println("Border Color: Red");
  }
}
```

### 步骤 5

使用 *RedShapeDecorator* 来装饰 *Shape* 对象。

#### DecoratorPatternDemo.java

```
public class DecoratorPatternDemo {
  public static void main(String[] args) {

    Shape circle = new Circle();
    ShapeDecorator redCircle = new RedShapeDecorator(new Circle());
    ShapeDecorator redRectangle = new RedShapeDecorator(new Rectangle());
    //Shape redCircle = new RedShapeDecorator(new Circle());
    //Shape redRectangle = new RedShapeDecorator(new Rectangle());
    System.out.println("Circle with normal border");
    circle.draw();

    System.out.println("\nCircle of red border");
    redCircle.draw();

    System.out.println("\nRectangle of red border");
    redRectangle.draw();
  }
}
```

### 步骤 6

执行程序，输出结果：
```
Circle with normal border
Shape: Circle

Circle of red border
Shape: Circle
Border Color: Red

Rectangle of red border
Shape: Rectangle
Border Color: Red
```

